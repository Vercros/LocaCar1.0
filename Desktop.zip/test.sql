create database test;
use test;

create table img (
id_img int primary key not null,
imagem_img blob,
descricao_img varchar (300)
);