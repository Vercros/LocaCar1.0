﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocaCar.Models
{
     class CadastrarCarro
    {
        public int id { get; set; }
        public string imagem { get; set; }
        public string descricao { get; set; }

    }
}
