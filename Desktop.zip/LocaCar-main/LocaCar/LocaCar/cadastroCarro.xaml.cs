﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Data.SqlClient;

namespace LocaCar
{
    /// <summary>
    /// Interação lógica para cadastroCarro.xam
    /// </summary>
    public partial class cadastroCarro : Page
    {
        public cadastroCarro()
        {
            InitializeComponent();
        }

        private void btnProcurar_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.ShowDialog();

            try
            {
                FileStream fs = new FileStream(dlg.FileName, FileMode.Open, FileAccess.Read);
                byte[] dadosImagem = new byte[fs.Length];
                fs.Read(dadosImagem, 0, System.Convert.ToInt32(fs.Length));
                fs.Close();

                ImageSourceConverter imgs = new ImageSourceConverter();
                imgArquivo.SetValue(Image.SourceProperty, imgs.ConvertFromString(dlg.FileName.ToString()));

                txtNome.Text = dlg.FileName.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :: " + ex.Message);
            }
        }

        private void btnSalvar_Click(object sender, RoutedEventArgs e)
        {
            {
                try
                {
                    SqlConnection thisConnection = new SqlConnection(@"Server=(local);Database=Test;Trusted_Connection=Yes;");
                    thisConnection.Open();
                    string sqlCmd = "INSERT INTO Fotos(imagem,nome) values(@imagem,@nome)";
                    SqlCommand sc = new SqlCommand(sqlCmd, thisConnection);
                    sc.Parameters.AddWithValue("@imagem", dadosImagem);
                    sc.Parameters.AddWithValue("@nome", txtNome.Text);
                    sc.ExecuteNonQuery();
                    sc.Dispose();
                    thisConnection.Close();
                    MessageBox.Show("Imagem Salva ");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro :: " + ex.Message);
                }
            }
        }
    }
}
